package dev.sixseven.mixin;

import dev.sixseven.SixSevenClient;
import dev.sixseven.gui.ClickGuiScreen;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.screen.ingame.BookEditScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Keyboard.class})
public class KeyboardHandlerMixin {
   @Inject(
      method = {"method_1466(JILnet/minecraft/class_11908;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void sixsevenclient$dispatchModuleKeybinds(long window, int action, KeyInput keyEvent, CallbackInfo ci) {
      MinecraftClient minecraft = MinecraftClient.getInstance();
      if (SixSevenClient.modules() != null && action == 1) {
         if (minecraft.currentScreen == null && minecraft.world != null) {
            if (SixSevenClient.modules().onKeyPressed(keyEvent.key())) {
               ci.cancel();
            }
         } else {
            if ((keyEvent.key() == 340 || keyEvent.key() == 344) && minecraft.currentScreen != null && shiftOpensGui(minecraft.currentScreen)) {
               minecraft.setScreen(new ClickGuiScreen(minecraft.currentScreen));
               ci.cancel();
            }
         }
      }
   }

   private static boolean shiftOpensGui(Screen screen) {
      return !(screen instanceof ClickGuiScreen)
            && !(screen instanceof ChatScreen)
            && !(screen instanceof HandledScreen)
            && !(screen instanceof AbstractSignEditScreen)
            && !(screen instanceof BookEditScreen)
         ? !(screen.getFocused() instanceof TextFieldWidget editBox && editBox.isFocused())
         : false;
   }
}
